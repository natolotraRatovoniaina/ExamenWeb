let produit = [];
let livres;

//fonction pour prendre les données dans le fichier json
async function prendreDonnée() {
  const response = await fetch("/json/livres.json");
  const data = await response.json();
  return data;
}

//fonction pour afficher les produits dans la page

function prendreProduit() {
  if (localStorage.getItem("livres") == null) {
    prendreDonnée()
      .then((data) => {
        localStorage.setItem("livres", JSON.stringify(data));
      })
      .catch((error) => console.log(error));
  }

  livres = JSON.parse(localStorage.getItem("livres"));
  produit = livres.livres;
  afficherProduit(produit);
}

//Afficher les produits
function afficherProduit(produit) {
  produit.forEach((e) => {
    const conteneurLivres = document.querySelector(".conteneur-livres");
    const conteneurLivre = document.createElement("div");
    conteneurLivre.classList = "conteneur-livre";

    const image = document.createElement("div");
    image.classList = "image";

    const img = document.createElement("img");
    img.src = e.image;
    img.alt = e.titre;

    image.appendChild(img);

    const info = document.createElement("div");
    info.classList = "conteneur-info";

    const titre = document.createElement("span");
    titre.innerText = "Titre: " + e.titre;

    const auteur = document.createElement("span");
    auteur.innerText = "Auteur: " + e.auteurs;

    const date = document.createElement("span");
    date.innerText = "Date de Publication: " + e.datePublication;

    info.appendChild(titre);
    info.appendChild(auteur);
    info.appendChild(date);
    const conteneurBoutonProd = document.createElement("div");
    conteneurBoutonProd.classList = "conteneur-bouton-prod";

    const bouton1 = document.createElement("button");
    bouton1.innerText = "Consulter";

    bouton1.addEventListener("click", () => {
      afficherDetail(e);
    });

    const bouton2 = document.createElement("button");
    bouton2.innerText = "Modifier";

    bouton2.addEventListener("click", () => {
      afficherFormMod(e);
    });

    const bouton3 = document.createElement("button");
    bouton3.innerText = "Supprimer";

    bouton3.addEventListener("click", () => {
      supprimerLivre(e, conteneurLivres, conteneurLivre);
    });

    conteneurBoutonProd.appendChild(bouton1);
    conteneurBoutonProd.appendChild(bouton2);
    conteneurBoutonProd.appendChild(bouton3);

    conteneurLivre.appendChild(image);
    conteneurLivre.appendChild(info);
    conteneurLivre.appendChild(conteneurBoutonProd);

    conteneurLivres.appendChild(conteneurLivre);
  });
}

//Evenement d'affichage des details :

function afficherDetail(e) {
  const conteneurDetail = document.querySelector(".conteneur-detail");
  conteneurDetail.innerHTML = `
  <div class="conteneur-img-detail">
      <img src="${e.image}" alt="${e.titre}" />
    </div>
    <div class="detail">
      <span>Titre: ${e.titre}</span>
      <span>Auteur: ${e.auteurs}</span>
      <span>Isbn: ${e.isbn}</span>
      <span>Éditeur: ${e.editeur}</span>
      <span>Date de Publication: ${e.datePublication}</span>
      <span>Genre: ${e.genre}</span>
      <p>Résumé: ${e.resume}</p>
      <span>Langue: ${e.langue}</span>
      <span>Pages: ${e.nombrePages}</span>
      <span>Disponibilité: ${e.disponibilite}</span>
      <span>État: ${e.etat}</span>
      <span>Emplacement: ${e.emplacement}</span>
    </div>
  `;
  return conteneurDetail;
}

// Afficher formulaire de modification

function afficherFormMod(e) {
  const sectionModifier = document.querySelector("#Modifier");
  sectionModifier.style.display = "flex";
  const sectionListes = document.querySelector("#Listes");
  sectionListes.style.display = "none";
  sectionModifier.innerHTML = `
      <form method="Post">
        <h1>Modifier le livre</h1>
        <div class="conteneur-input">
          <label for="titre">Titre :</label>
          <input type="text" name="titre" id="titre" value="${e.titre}" required />
        </div>
        <div class="conteneur-input">
          <label for="auteur"> Auteur :</label>
          <input type="text" name="auteur" id="auteur" value="${e.auteurs}" required />
        </div>
        <div class="conteneur-input">
          <label for="isbn">Isbn :</label>
          <input type="text" name="isbn" id="isbn" value="${e.isbn}" required />
        </div>
        <div class="conteneur-input">
          <label for="editeur">Éditeur :</label>
          <input type="text" name="editeur" id="editeur" value="${e.editeur}" required />
        </div>
        <div class="conteneur-input">
          <label for="date">Date de publication :</label>
          <input type="text" id="date" name="date" value="${e.datePublication}" required />
        </div>
        <div class="conteneur-input">
          <label for="">Genre du livre :</label>
          <textarea name="genre" required>${e.genre}</textarea>
        </div>
        <div class="conteneur-input">
          <label for="resume">Résumé du livre :</label>
          <textarea name="resume" id="resume" required>${e.resume}</textarea>
        </div>
        <div class="conteneur-input">
          <label for="langue">Langue du livre :</label>
          <input type="text" id="langue" name="langue" value="${e.langue}" required/>
        </div>
        <div class="conteneur-input">
          <label for="nbrPage">Nombre de page :</label>
          <input type="number" id="nbrPage" name="page" value="${e.nombrePages}" min="1" required/>
        </div>
        <div class="conteneur-input">
          <label for="etat">État du livre :</label>
          <input type="text" id="etat" name="etat" value="${e.etat}" required />
        </div>
        <div class="conteneur-input">
          <label for="img">Image du livre :</label>
          <input type="file" id="img" name="image" required />
        </div>
        <div class="conteneur-bouton">
          <button class="modifier" type="button">Modifier</button>
        </div>
      </form>`;
}

// Fonction supprimer livres

function supprimerLivre(e, conteneurLivres, conteneurLivre) {
  const produitTmp = produit.filter((elt) => elt.titre != e.titre);
  produit = produitTmp;
  conteneurLivres.removeChild(conteneurLivre);
  livres.livres = produit;
  localStorage.setItem("livres", JSON.stringify(livres));
}

// Afficher formulaire d'ajouter

const formAjout = document.querySelector(".ajout");
formAjout.addEventListener("click", () => {
  const sectionAjout = document.querySelector("#Ajout");
  const sectionListe = document.querySelector("#Listes");
  const sectionModifier = document.querySelector("#Modifier");

  sectionAjout.style.display = "flex";
  sectionListe.style.display = "none";
  sectionModifier.style.display = "none";
});

// Afficher la liste

const dispListe = document.querySelector(".listes");
dispListe.addEventListener("click", () => {
  const sectionAjout = document.querySelector("#Ajout");
  const sectionListe = document.querySelector("#Listes");
  const sectionModifier = document.querySelector("#Modifier");

  sectionAjout.style.display = "none";
  sectionListe.style.display = "block";
  sectionModifier.style.display = "none";
});

// Ajouter des livres

const ajouter = document.querySelector(".ajouter");
ajouter.addEventListener("click", () => {
  const input = document.querySelectorAll("input");
  const nouveauLivre = {};
  const table = [
    "titre",
    "auteurs",
    "isbn",
    "image",
    "editeur",
    "datePublication",
    "genre",
    "resume",
    "langue",
    "nombrePages",
    "disponibilite",
    "etat",
    "emplacement",
  ];
  let i = 0;
  table.forEach((e) => {
    nouveauLivre[e] = input[i].value;
  });
});
prendreProduit();
